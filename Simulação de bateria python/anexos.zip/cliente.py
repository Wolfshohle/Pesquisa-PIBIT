# cliente.py
import socket

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect(("172.172.21.209", 5555))

while True:
    data = client.recv(1024).decode()
    print(data)
    if "Fim de jogo" in data:
        break
    if "[" in data:  # print do tabuleiro
        jogada = input("Sua jogada (0-8): ")
        client.sendall(jogada.encode())
