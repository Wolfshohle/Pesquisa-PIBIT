# tabuleiro.py
class jogoDaVelha:
    def __init__(self):
        self.tabuleiro = [" "]*9
        self.jogador_atual = "X"

    def jogar(self, posicao):
        if self.tabuleiro[posicao] == " ":
            self.tabuleiro[posicao] = self.jogador_atual
            self.jogador_atual = "O" if self.jogador_atual == "X" else "X"
            return True
        return False

    def verificar_vencedor(self):
        combinacoes = [
            (0,1,2), (3,4,5), (6,7,8),
            (0,3,6), (1,4,7), (2,5,8),
            (0,4,8), (2,4,6)
        ]
        for a,b,c in combinacoes:
            if self.tabuleiro[a] == self.tabuleiro[b] == self.tabuleiro[c] != " ":
                return self.tabuleiro[a]
        if " " not in self.tabuleiro:
            return "Empate"
        return None
