# servidor.py
import socket
import threading
from jogo_da_velha import jogoDaVelha

jogo = jogoDaVelha()
jogadores = []

def lidar_com_jogador(conn, jogador_id):
    conn.sendall(f"Você é o jogador {['X', 'O'][jogador_id]}".encode())
    while True:
        conn.sendall(str(jogo.tabuleiro).encode())
        pos = conn.recv(1024).decode()
        if jogo.jogador_atual == ['X', 'O'][jogador_id]:
            if jogo.jogar(int(pos)):
                vencedor = jogo.verificar_vencedor()
                if vencedor:
                    for p in jogadores:
                        p.sendall(f"Fim de jogo! Vencedor: {vencedor}".encode())
                    break

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind(("0.0.0.0", 5555))
server.listen(2)

print("Servidor aguardando jogadores...")
while len(jogadores) < 2:
    conn, addr = server.accept()
    jogadores.append(conn)
    threading.Thread(target=lidar_com_jogador, args=(conn, len(jogadores)-1)).start()
